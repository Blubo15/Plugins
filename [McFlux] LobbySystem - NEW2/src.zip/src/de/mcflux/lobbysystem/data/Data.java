package de.mcflux.lobbysystem.data;

public class Data {
	
	private static String prefix = "";
	
	public static void setPrefix(String prefix) {
		Data.prefix = prefix;
	}
	
	public static String getPrefix() {
		return prefix;
	}

}
