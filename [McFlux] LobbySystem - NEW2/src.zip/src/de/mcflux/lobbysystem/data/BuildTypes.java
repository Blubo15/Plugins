package de.mcflux.lobbysystem.data;

public enum BuildTypes {

	CAN_NOT_BUILD,
	CAN_BUILD;
	
}
