package de.mcflux.lobbysystem.manager;

public enum CoinTypes {
	
	FREEBUILD, LOBBY, CITYBUILD; 

}
